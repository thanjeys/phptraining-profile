<?php

include '../inc.database.php';

// get the requested data
$start = $_GET['start'];
$length = $_GET['length'];
$searchValue = $_GET['search']['value'];
$genderValue = $_GET['gender'];
$order = $_GET['order'];

// For Ordering table
$columnArray = [
		'id',
    'name',
    'age',
    'gender',
    'city'
];

$sql = 'SELECT * FROM profiles';
$totalRecords = $con->query($sql)->num_rows;

// Search query
$searchQuery = [];
array_push($searchQuery, 'name LIKE "%'.$searchValue.'%"');
array_push($searchQuery, ' OR age LIKE "%'.$searchValue.'%"');
array_push($searchQuery, ' OR gender LIKE "%'.$searchValue.'%"');
array_push($searchQuery, ' OR city LIKE "%'.$searchValue.'%"');

$searchSql = " ". implode(" ", $searchQuery);

// Gender condition
$genderCondition = NULL;
if (!empty($genderValue))
{
    $genderCondition = ' gender LIKE "'.$genderValue.'" AND ';
}

$whereText = ' WHERE ';
$limit = " LIMIT $start, $length";
$orderBy = " ORDER BY ".$columnArray[$order[0]['column']]." ".$order[0]['dir']." ";

$sql .= $whereText;
$sql .= $genderCondition;
$sql .= " (".$searchSql.")";

$filteredRecords = $con->query($sql)->num_rows;

$sql .= $orderBy;
$sql .= $limit;

// echo $sql;
$result = $con->query($sql);
while ($row = $result->fetch_assoc()) {
    $records[] = [
        'id' => $row['id'],
        'name' => $row['name'],
        'age' => $row['age'],
        'gender' => $row['gender'],
        'city' => $row['city'],
        'address' => $row['address'],
        'hobbies' => $row['hobbies'],
        'photo_path' => $row['photo_path'],
    ];
}

// build the response data
$response = array(
    "draw" => intval($_GET['draw']),
    "recordsTotal" => $totalRecords,
    "recordsFiltered" => $filteredRecords,
    "data" => $records ?? ''
);

// return the response as JSON
echo json_encode($response);


			