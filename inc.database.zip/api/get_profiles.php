<?php

include '../inc.database.php';


$sql = 'SELECT * FROM profiles';
$result = $con->query($sql);

$i = 1;
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $records[] = [
            'id' => $row['id'],
            'name' => $row['name'],
            'age' => $row['age'],
            'gender' => $row['gender'],
            'city' => $row['city'],
            'address' => $row['address'],
            'hobbies' => $row['hobbies'],
            'photo_path' => $row['photo_path'],
        ];
    }
    $status = 'succuess';
    $result = $records;
} else {
    $status = 'failed';
    $message = 'No Records';
    $result = '';
}

$jsonRes = [
    'status' => $status,
    'message' => $message ?? NULL,
    'result' => $result
];
$jsonRes = mb_convert_encoding($jsonRes, 'UTF-8');

// Encode to JSON
echo json_encode($jsonRes);



			