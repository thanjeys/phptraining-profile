<?php

include '../inc.database.php';

$id = $_GET['id'];
$sql = 'SELECT * FROM profiles WHERE id="'.$id.'"';
$result = $con->query($sql);
if ($result->num_rows > 0) {
	$row = $result->fetch_assoc();

    $jsonRes = [
        'status' => 'success',
        'result' => $row
    ];
}
else {
    $jsonRes = [
        'status' => 'failed',
        'message' => 'No records found' 
    ];
} 

echo json_encode($jsonRes);
