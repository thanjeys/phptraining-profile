<?php
include_once '../inc.database.php';

$request_body  = file_get_contents('php://input');
$data = json_decode($request_body, true);

if (isset($data['id'])) {
	$id = $data['id'];
	$sql = 'DELETE FROM profiles WHERE id="' . $id . '"';
	$con->query($sql);
}
echo 'successully deleted';


?>