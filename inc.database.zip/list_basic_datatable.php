<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Profiles</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
	<div class="container">
		<h1>Profiles with Datatable</h1>
		<hr>
		<table id="profileTable" class="table">
			<thead>
				<tr>
					<th>S.No</th>
					<th>Name</th>
					<th>Age</th>
					<th>Gender</th>
					<th>City</th>
				</tr>
			</thead>
			<tbody>
			</tbody>
		</table>
	</div>

<!-- Load jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- Load DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
<!-- Load DataTables JS -->
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script> 
	$(document).ready(function() {
		$('#profileTable').DataTable({
			ajax: {
				url: 'api/get_profiles.php', // replace with the URL of your JSON endpoint
				dataSrc: 'result' // replace with the name of the property that contains the data array in your JSON response
			},
			columns: [
			{ data: 'id' },
			{ data: 'name' },
			{ data: 'gender' },
			{ data: 'city' },
			{ data: 'address' }
			]
		});
});

</script>
</body>

</html>