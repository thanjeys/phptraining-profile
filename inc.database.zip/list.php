<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]>      <html class="no-js"> <!--<![endif]-->
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Profiles</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
	<div class="container">
		<h1>Profiles</h1>
		<hr>
		<table id="profileTable" class="table">
			<thead>
				<tr>
					<th>S.No</th>
					<th>Name</th>
					<th>Age</th>
					<th>Gender</th>
					<th>City</th>
					<th>Address</th>
					<th>Hobbies</th>
					<th>Picture</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
			</tbody>
		</table>
	</div>
	<script>
		document.addEventListener('DOMContentLoaded', function() {
			getProfiles();
		});

		function getProfiles() {
			fetch('api/get_profiles.php')
				.then(res => res.json())
				.then(data => displayProfiles(data.result))
				.catch(error => console.log('error', error));
		}

		function displayProfiles(results) {
			console.log(results);
			// Get the table body element
			let tableBody = document.querySelector('#profileTable tbody');

			results.forEach(item => {
				let row = document.createElement('tr');
				row.id = item.id;
				row.innerHTML = `
					<td>${item.id}</td>
					<td>${item.name}</td>
					<td>${item.age}</td>
					<td>${item.gender}</td>
					<td>${item.city}</td>
					<td>${item.address}</td>
					<td>${item.hobbies}</td>
					<td><img src="uploads/${item.photo_path}" alt="${item.name} Photo" width="100"></td>
					<td><a href="update.php?id=${item.id}">Edit</a>
					<a class="delete_profile" data-id=${item.id} data-name=${item.name} href="#">Delete</a>
					</td>`;
				tableBody.appendChild(row);
			});

			document.querySelectorAll('.delete_profile').forEach(deleteAction => {
				deleteAction.addEventListener('click', event => {
					event.preventDefault();
					const id = deleteAction.dataset.id;
					const name = deleteAction.dataset.name;
					deleteProfile(id, name)
				});
			});
		}


		function deleteProfile(id, name) {
			if (confirm(`Are you sure to delete ${name}'s profile?`)) {
				fetch('api/delete_profile.php', {
						method: 'POST',
						body: JSON.stringify({
							id: id
						})
					})
					.then(res => res.text())
					.then(data => {
						const tableRow = document.querySelector(`tr[id="${id}"]`);
						tableRow.remove();
					})
					.catch(error => console.log('error', error));

			} else {
				return false;
			}
		}

		
	</script>
</body>

</html>