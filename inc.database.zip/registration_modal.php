<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Registration</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>

	<div class="container">
		<div class="row">
			<h1>New Profile</h1>
			<hr>

			<!-- Modal trigger button -->
			<button type="button" class="btn btn-primary btn-lg btn-block" data-bs-toggle="modal" data-bs-target="#newProfileModal">
				New Profile
			</button>

			<!-- Modal Body -->
			<!-- if you want to close by clicking outside the modal, delete the last endpoint:data-bs-backdrop and data-bs-keyboard -->
			<div class="modal fade" id="newProfileModal" tabindex="-1" data-bs-backdrop="static" data-bs-keyboard="false" role="dialog" aria-labelledby="modalTitleId" aria-hidden="true">
				<div class="modal-dialog modal-dialog-scrollable modal-dialog-centered modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="modalTitleId">Registration</h5>
							<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
						<div class="modal-body">
							<form action="" id="store_profile" method="POST" enctype="multipart/form-data">
								<div class="mb-3">
									<label for="name" class="form-label">Name</label>
									<input type="text" required name="name" class="form-control" id="name" placeholder="Your Name">
								</div>
								<div class="mb-3">
									<label for="email" class="form-label">Email address</label>
									<input type="email" required name="email" class="form-control" id="email" placeholder="name@example.com">
								</div>
								<div class="mb-3">
									<label for="age" class="form-label">Age</label>
									<input type="number" name="age" required class="form-control" id="age" placeholder="Your age">
								</div>
								<div class="mb-3">
									<label for="height" class="form-label">Height (Feets)</label>
									<input type="number" name="height" required step="any" class="form-control" id="height" placeholder="5.6">
								</div>
								<div class="mb-3">
									<label for="dob" class="form-label">Date of Birth</label>
									<input type="date" name="dob" required class="form-control" id="dob" placeholder="Your dob">
								</div>
								<div class="mb-3">
									<label class="form-label">Gender</label> <br>
									<input class="form-check-input" type="radio" name="gender" id="male" value="male">
									<label class="form-check-label" for="male">
										Male
									</label>
									<input class="form-check-input" type="radio" name="gender" id="female" value="female">
									<label class="form-check-label" for="female">
										Female
									</label>
								</div>
								<div class="mb-3">
									<label for="dob" class="form-label">Hobbies</label> <br>
									<input class="form-check-input" type="checkbox" name="hobbies[]" id="cricket" value="Playing Cricket">
									<label class="form-check-label" for="cricket">
										Playing Cricket
									</label>
									<input class="form-check-input" type="checkbox" name="hobbies[]" id="chess" value="Playing Chess">
									<label class="form-check-label" for="chess">
										Playing Chess
									</label>
									<input class="form-check-input" type="checkbox" name="hobbies[]" id="music" value="Music">
									<label class="form-check-label" for="music">
										Music
									</label>

								</div>

								<div class="mb-3">
									<label for="address" class="form-label">Address</label>
									<textarea name="address" id="address" class="form-control" cols="30" rows="4"></textarea>
								</div>
								<div class="mb-3">
									<label for="age" class="form-label">City</label>
									<select name="city" class="form-control" id="city">
										<option selected disabled>Select</option>
										<option value="chennai">Chennai</option>
										<option value="hyderabad">Hyderabad</option>
										<option value="delhi">Delhi</option>
										<option value="mumbai">Mumbai</option>
									</select>
								</div>
								<div class="mb-3">
									<label for="photo" class="form-label">Your Photo</label>
									<input type="file" name="photo" class="form-control" id="photo">
								</div>

						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
							<button type="submit" class="btn btn-primary">Submit</button>
						</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
		integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
	</script>
	
	<!-- Bootstrap JavaScript Libraries -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
	</script>

<script>
		var newProfileModal = new bootstrap.Modal(document.getElementById('newProfileModal'));
						
		const form = document.querySelector('#store_profile');
		form.addEventListener('submit', (event) => {
			event.preventDefault();
			const formData = new FormData(form);
			fetch('api/store_profile.php', {
					method: 'POST',
					body: formData
				})
				.then(res => res.json())
				.then(data => {
					if (data.status == 'success') {
						newProfileModal.hide();
						alert('Successfully Saved');
					}
					console.log(data)
				})
				.catch(error => console.log('Error', error));
		});
	</script>
	
</body>
</html>
