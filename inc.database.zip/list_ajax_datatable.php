<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Profiles</title>
	<meta name="description" content="">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
	<div class="container">
		<h1>Profiles with Datatable</h1>
		<hr>
		
		<label for="gender">Gender:</label>
		<select class="form-control" id="gender">
			<option value="">-- All --</option>
			<option value="male">Male</option>
			<option value="female">Female</option>
		</select>
		<hr>
		<table id="profileTable" class="table">
			<thead>
				<tr>
					<th>S.No</th>
					<th>Name</th>
					<th>Age</th>
					<th>Gender</th>
					<th>City</th>
					<th>Photo</th>
					<th></th>
				</tr>
			</thead>
			<tbody>
			</tbody>
		</table>
	</div>

	<!-- Load jQuery -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
	<!-- Load DataTables CSS -->
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
	<!-- Load DataTables JS -->
	<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
	<script>
		$(document).ready(function() {
			var dataTable = $('#profileTable').DataTable({
				serverSide: true,
				ajax: {
					url: 'api/get_profiles_ajax.php', // replace with the URL of your JSON endpoint
					type: 'GET',
					data: function(d) {
						d.start = d.start;
						d.length = d.length;
						d.search.value = $('input[type="search"]').val();
						d.gender = $('#gender').val();
					},
					dataType: 'json'
				},
				columns: [{
						data: 'id'
					},
					{
						data: 'name'
					},
					{
						data: 'age'
					},
					{
						data: 'gender'
					},
					{
						data: 'city'
					},
					{
						"data": "photo_path",
						"render": function(data, type, row, meta) {
							return '<img src="' + data + '" alt="' + row.name + ' Photo" width="100">';
						}
					},
					{
						"data": "id",
						"render": function(data, type, row, meta) {
							return '<a href="update.php?id=' + data + '">Edit</a> <a href="delete.php' + data + '">Delete</a>';
						}
					},
				],
				order: [
					[1, "asc"]
				]
			});

			$('#gender').on('change', function() {
				dataTable.draw();
			});
		});
	</script>
</body>

</html>